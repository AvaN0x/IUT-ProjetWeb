
Fichiers à NE PAS TOUCHER : 
    style.css
    mobile.css

Fichiers à modifier : 
    [la page que tu dois faire].html
    s[la page que tu dois faire].css    -> version ordi
    m[la page que tu dois faire].css    -> version mobile

Info pour la page : 
    <header>
     <p> 
    texte en dessous du header, à modifier

    <div class="backimg univac"></div>
        pour changer l'image, vous avez juste a modifier la class "univac" et la créer dans le fichier correspondant a votre page
        j'ai mis le format dans les diff fichiers css
        mettez la source de l'image en commentaire dans le css    

    <a class="source" href="https://www.google.com" title="https://www.google.com" target="_blank">Source: google.com</a>
        mettez bien le liens pour le href="" et le title=""

    <a href="#" class="haut_de_page">↑ Retour en haut de page</a>
        bien le laisser à la fin de chaque <section>
        il ne s'affiche que sur mobile

NE PAS TOUCHER à :
    nav
    footer
    div body

Donc il faut juste modifier : 
    .backimg
    l'INTERIEUR du #body (section et article)


EVITEZ DE TOUCHER LES COULEURS POUR LE MOMENT !!!!
Pour les couleurs on va tous en parler de notre coter, on va d'abord tout faire en noir et blanc comme c'est le cas actuellement !
On se verra en vocal + screenshare pour changer les couleurs

N'hésitez pas à mettre des images, des iframes et autres


RAPPEL : 
VOUS NE TOUCHEZ SURTOUT PAS AUX FICHIERS STYLE.CSS ET MOBILE.CSS
- evolution.html : Clément
- enjeux.html : Valentin
- influence.html : Alexandre
- nature.html : Gauthier
